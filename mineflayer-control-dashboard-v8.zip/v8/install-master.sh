#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Node.js 22+ is required"; exit 1; }
command -v npm >/dev/null || { echo "npm is required"; exit 1; }
command -v pm2 >/dev/null || { echo "Install PM2 first: npm install -g pm2"; exit 1; }
if [ ! -f .env ]; then cp .env.master.example .env; echo "Created .env from .env.master.example. Edit it, then run this script again."; exit 0; fi
npm install
npm run check
npm test
pm2 startOrRestart ecosystem.master.config.cjs
pm2 save
pm2 status
