# VPS cluster setup

This setup assumes the host provides multiple **16 GB containers** with private network reachability between the master and workers.

## Layout

```text
180 GB host
├── Master        ~2–4 GB
├── Worker w01    16 GB
├── Worker w02    16 GB
├── Worker w03    16 GB
├── Worker w04    16 GB
├── Worker w05    16 GB
├── Worker w06    16 GB
├── Worker w07    16 GB
├── Worker w08    16 GB
├── Worker w09    16 GB
└── Worker w10    16 GB
```

That leaves operational headroom instead of allocating every GB to bot containers. With `MAX_BOTS=200` on each worker, the master can request up to 2,000 bots.

## 1. Install the project on the master

Upload/extract the ZIP and enter its directory:

```bash
mkdir -p ~/mineflayer-cluster
cd ~/mineflayer-cluster
```

Copy the master environment:

```bash
cp .env.master.example .env
nano .env
```

Generate one cluster key:

```bash
openssl rand -hex 32
```

Put that value into `WORKER_API_KEY=` in the master `.env`. Use the **same value** in every worker `.env`.

Replace the example `WORKER_URLS` with the real private IPs of your worker containers.

Then:

```bash
npm install
npm run check
npm test
npm install -g pm2
pm2 start ecosystem.master.config.cjs
pm2 save
pm2 status
```

## 2. Prepare every worker container

Copy the same project into worker 01 and run:

```bash
cd ~/mineflayer-cluster
cp .env.worker.example .env
nano .env
```

Worker 01 should have:

```text
WORKER_ID=w01
WORKER_PORT=3101
WORKER_API_KEY=<same cluster key>
MAX_BOTS=200
```

Worker 02 uses `WORKER_ID=w02`, worker 03 uses `w03`, and so on.

Then on each worker:

```bash
npm install
npm run check
npm install -g pm2
pm2 start ecosystem.worker.config.cjs
pm2 save
pm2 status
```

## 3. Test master → worker connectivity

On the master, replace `WORKER_IP` with a worker's private IP and use the cluster key:

```bash
set -a; . ./.env; set +a
curl -fsS -H "X-Worker-Key: $WORKER_API_KEY" http://WORKER_IP:3101/healthz
```

A healthy worker returns JSON containing `role: worker`, its `workerId`, `maxBots`, and current bot count.

Do this for all ten workers before starting a large fleet.

## 4. Start from the dashboard

Open the master dashboard on port 3000 (or your configured `WEB_PORT`). Enter the Minecraft server details and choose the desired bot count.

For 2,000 bots with ten workers and a 5-second global join delay, the master distributes about 200 bots per worker. Each worker receives a staggered starting offset and uses a local interval equal to `5 × 10 = 50 seconds`, so the fleet still starts at roughly one connection every 5 seconds instead of ten connections at once.

## 5. PM2 monitoring

Master:

```bash
pm2 status
pm2 monit
pm2 logs mineflayer-master
```

Each worker container:

```bash
pm2 status
pm2 monit
pm2 logs mineflayer-worker
```

PM2 is intentionally **one worker process per 16 GB container**. Do not use PM2 cluster mode to create multiple copies of the same worker inside a 16 GB container.

## 6. Scaling beyond ten workers

Add another worker URL to `WORKER_URLS`, give the new container a unique `WORKER_ID`, and increase its `MAX_BOTS` only after benchmarking. The master can use up to its configured `MAX_TOTAL_BOTS` limit.

## 7. Network/security

Expose the dashboard port publicly only through your chosen reverse proxy/VPN/firewall. Worker port `3101` should be private and restricted to the master whenever your container network allows it. Never put the cluster key or an OpenAI API key into the browser UI, Git, or a public repository.
