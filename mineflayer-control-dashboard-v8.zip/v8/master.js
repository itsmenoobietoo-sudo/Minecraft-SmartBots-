'use strict'

const path = require('node:path')
const crypto = require('node:crypto')
const http = require('node:http')
const express = require('express')
const { Server } = require('socket.io')
require('dotenv').config()

const app = express()
const httpServer = http.createServer(app)
const io = new Server(httpServer, { maxHttpBufferSize: 64 * 1024 })

const WEB_PORT = Number(process.env.WEB_PORT || 3000)
const WEB_USER = String(process.env.WEB_USER || '')
const WEB_PASSWORD = String(process.env.WEB_PASSWORD || '')
const MASTER_WORKER_KEY = String(process.env.WORKER_API_KEY || '')
const POLL_MS = Math.max(500, Math.min(5000, Number(process.env.WORKER_POLL_MS || 1000)))
const REQUEST_TIMEOUT_MS = Math.max(1000, Math.min(15_000, Number(process.env.WORKER_REQUEST_TIMEOUT_MS || 5000)))
const MAX_TOTAL_BOTS = Math.max(1, Math.min(2000, Number(process.env.MAX_TOTAL_BOTS || 2000)))

const workers = parseWorkers(process.env.WORKER_URLS || '')
const workerState = new Map(workers.map(w => [w.id, {
  id: w.id, url: w.url, online: false, maxBots: 0, bots: 0, state: null, error: null, checkedAt: null
}]))
let masterRun = null
let startInProgress = false
let pollTimer = null
let lastAggregate = null
let lastLogsSignature = ''

const MAX_LOGS = 500
const apiHits = new Map()
let logBuffer = []

function parseWorkers(raw) {
  const out = []
  const seen = new Set()
  for (const item of raw.split(',').map(x => x.trim()).filter(Boolean)) {
    const [urlPart, idPart] = item.split('|').map(x => x.trim())
    const url = new URL(urlPart)
    if (!['http:', 'https:'].includes(url.protocol)) throw new Error(`Unsupported worker URL protocol: ${url.protocol}`)
    const id = (idPart || `worker-${out.length + 1}`).replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 32)
    if (!id || seen.has(id)) throw new Error(`Duplicate/invalid worker id: ${id}`)
    seen.add(id)
    out.push({ id, url: url.toString().replace(/\/$/, '') })
  }
  if (!out.length) throw new Error('WORKER_URLS must contain at least one worker')
  return out
}

function authEnabled () { return Boolean(WEB_USER && WEB_PASSWORD) }
function basicAuth (req, res, next) {
  if (!authEnabled()) return next()
  const header = req.headers.authorization || ''
  if (!header.startsWith('Basic ')) {
    res.setHeader('WWW-Authenticate', 'Basic realm="Mineflayer Cluster Dashboard"')
    return res.status(401).send('Authentication required')
  }
  let decoded
  try { decoded = Buffer.from(header.slice(6), 'base64').toString('utf8') } catch { return res.status(401).send('Invalid credentials') }
  const sep = decoded.indexOf(':')
  const user = sep >= 0 ? decoded.slice(0, sep) : ''
  const password = sep >= 0 ? decoded.slice(sep + 1) : ''
  const userBuf = Buffer.from(user)
  const passBuf = Buffer.from(password)
  const expectedUser = Buffer.from(WEB_USER)
  const expectedPass = Buffer.from(WEB_PASSWORD)
  if (userBuf.length === expectedUser.length && passBuf.length === expectedPass.length && crypto.timingSafeEqual(userBuf, expectedUser) && crypto.timingSafeEqual(passBuf, expectedPass)) return next()
  res.setHeader('WWW-Authenticate', 'Basic realm="Mineflayer Cluster Dashboard"')
  return res.status(401).send('Invalid credentials')
}

function apiGuard (req, res, next) {
  if (req.method === 'POST') {
    const origin = String(req.headers.origin || '')
    const host = String(req.headers.host || '')
    if (origin && !origin.startsWith(`http://${host}`) && !origin.startsWith(`https://${host}`)) return res.status(403).json({ error: 'Invalid request origin' })
    const now = Date.now()
    const key = req.ip || req.socket.remoteAddress || 'unknown'
    const item = apiHits.get(key) || { start: now, count: 0 }
    if (now - item.start >= 60_000) { item.start = now; item.count = 0 }
    item.count += 1
    apiHits.set(key, item)
    if (item.count > 120) return res.status(429).json({ error: 'Rate limit exceeded' })
    if (apiHits.size > 5000) for (const [k, v] of apiHits) if (now - v.start > 120_000) apiHits.delete(k)
  }
  next()
}

app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff')
  res.setHeader('X-Frame-Options', 'DENY')
  res.setHeader('Referrer-Policy', 'same-origin')
  res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()')
  next()
})
app.use(basicAuth)
app.use(express.json({ limit: '32kb' }))
app.use(apiGuard)
app.use(express.static(path.join(__dirname, 'public'), { etag: true, maxAge: '1h' }))

function emitLog(message, level = 'info') {
  const item = { ts: new Date().toISOString(), level, message: String(message).slice(0, 500) }
  logBuffer.push(item)
  if (logBuffer.length > MAX_LOGS) logBuffer.shift()
  io.emit('log', item)
}

function workerHeaders() {
  return { 'x-worker-key': MASTER_WORKER_KEY, accept: 'application/json' }
}

async function workerFetch(worker, apiPath, options = {}) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS)
  try {
    const headers = { ...workerHeaders(), ...(options.headers || {}) }
    const response = await fetch(`${worker.url}${apiPath}`, {
      ...options,
      headers,
      signal: controller.signal
    })
    const data = await response.json().catch(() => ({}))
    if (!response.ok) throw new Error(`${worker.id}: HTTP ${response.status} ${data.error || ''}`.trim())
    return data
  } finally {
    clearTimeout(timer)
  }
}

async function pollOne(worker) {
  const target = workerState.get(worker.id)
  try {
    const data = await workerFetch(worker, '/api/state')
    target.online = true
    target.maxBots = Number(data?.worker?.maxBots || data?.run?.workerMaxBots || target.maxBots || 0)
    target.bots = Array.isArray(data.bots) ? data.bots.length : 0
    target.state = data
    target.error = null
    target.checkedAt = Date.now()
    return target
  } catch (error) {
    try {
      const health = await workerFetch(worker, '/healthz')
      target.online = Boolean(health.ok)
      target.maxBots = Number(health.maxBots || target.maxBots || 0)
      target.bots = Number(health.bots || 0)
      target.error = null
      target.checkedAt = Date.now()
    } catch (healthError) {
      target.online = false
      target.error = healthError?.message || error?.message || String(error)
      target.checkedAt = Date.now()
    }
    target.state = null
    return target
  }
}

function mergedLogs() {
  const merged = [...logBuffer]
  for (const target of workerState.values()) {
    for (const item of target.state?.logs || []) merged.push({ ...item, message: `[${target.id}] ${item.message}` })
  }
  merged.sort((a, b) => String(a.ts).localeCompare(String(b.ts)))
  return merged.slice(-MAX_LOGS)
}

function recoverMasterRunIfNeeded() {
  if (masterRun) return
  const active = [...workerState.values()].filter(target => target.state?.run)
  if (!active.length) return
  const first = active[0].state.run
  const maxBots = active.reduce((sum, target) => sum + Number(target.state?.run?.maxBots || 0), 0)
  const inferredGlobalDelay = Math.max(1000, Math.trunc(Number(first.joinDelayMs || 5000) / Math.max(1, workers.length)))
  const publicCopy = {
    host: first.host,
    port: first.port,
    maxBots,
    joinDelayMs: inferredGlobalDelay,
    version: first.version || 'auto',
    startedAt: first.startedAt || Date.now(),
    defaultMode: first.defaultMode || 'wander',
    fullDiamondSpeedrun: Boolean(first.fullDiamondSpeedrun),
    autoReconnect: Boolean(first.autoReconnect),
    reconnectDelayMs: Number(first.reconnectDelayMs || 5000),
    maxReconnects: Number(first.maxReconnects || 5),
    aiChatEnabled: Boolean(first.aiChatEnabled),
    ambientChatEnabled: Boolean(first.ambientChatEnabled),
    ambientIntervalMs: Number(first.ambientIntervalMs || 10000),
    aiAmbientEnabled: Boolean(first.aiAmbientEnabled),
    testAreaRadius: Number(first.testAreaRadius || 128),
    miningEnabled: Boolean(first.miningEnabled),
    combatEnabled: Boolean(first.combatEnabled),
    authMode: first.authMode || 'none',
    worldEntryEnabled: Boolean(first.worldEntryEnabled),
    worldCommand: first.worldCommand || '/rtp',
    worldWaitMs: Number(first.worldWaitMs || 4000),
    startupTimeoutMs: Number(first.startupTimeoutMs || 45000),
    runId: `recovered-${crypto.randomBytes(4).toString('hex')}`,
    recovered: true,
    workerCount: workers.length
  }
  masterRun = { id: publicCopy.runId, public: publicCopy }
  emitLog(`Recovered active worker run for ${maxBots} bots across ${active.length} worker(s).`, 'warn')
}

function aggregateState() {
  const bots = []
  const workerSummary = []
  let onlineWorkers = 0
  let workerBotCapacity = 0
  let observedBots = 0
  for (const target of workerState.values()) {
    if (target.online) onlineWorkers += 1
    workerBotCapacity += target.maxBots || 0
    observedBots += target.bots || 0
    const workerBots = target.state?.bots || []
    bots.push(...workerBots.map(bot => ({ ...bot, workerId: bot.workerId || target.id })))
    workerSummary.push({ id: target.id, online: target.online, maxBots: target.maxBots, bots: target.bots, error: target.error })
  }

  if (!masterRun) {
    return { run: null, bots, logs: mergedLogs(), cluster: { workerCount: workers.length, onlineWorkers, workerBotCapacity, observedBots, workers: workerSummary } }
  }

  let spawned = 0
  for (const target of workerState.values()) spawned += Number(target.state?.run?.spawnIndex || 0)
  const first = [...workerState.values()].find(x => x.state?.run)?.state?.run || {}
  const run = {
    ...masterRun.public,
    joinDelayMs: masterRun.public.joinDelayMs || Math.max(1000, Math.trunc(Number(first.joinDelayMs || 5000) / Math.max(1, workers.length))),
    spawnIndex: spawned,
    startedAt: masterRun.public.startedAt,
    maxBots: masterRun.public.maxBots,
    workerCount: workers.length,
    onlineWorkers,
    workers: workerSummary
  }
  // Prefer live run fields from workers where available, while keeping the master copy for fields hidden in worker state.
  for (const key of ['host','port','version','defaultMode','fullDiamondSpeedrun','autoReconnect','reconnectDelayMs','maxReconnects','aiChatEnabled','ambientChatEnabled','ambientIntervalMs','aiAmbientEnabled','testAreaRadius','miningEnabled','combatEnabled','authMode','worldEntryEnabled','worldCommand','worldWaitMs','startupTimeoutMs']) {
    if (first[key] !== undefined) run[key] = first[key]
  }
  return { run, bots, logs: mergedLogs(), cluster: { workerCount: workers.length, onlineWorkers, workerBotCapacity, observedBots, workers: workerSummary } }
}

function equalEnough(a, b) {
  try { return JSON.stringify(a) === JSON.stringify(b) } catch { return false }
}

async function pollAll() {
  await Promise.all(workers.map(pollOne))
  recoverMasterRunIfNeeded()
  const next = aggregateState()
  const publicState = { run: next.run, bots: next.bots, cluster: next.cluster }
  if (!equalEnough(publicState, lastAggregate)) {
    lastAggregate = publicState
    io.emit('state', publicState)
  }
  const logsSignature = JSON.stringify(next.logs)
  if (logsSignature !== lastLogsSignature) {
    lastLogsSignature = logsSignature
    io.emit('logs', next.logs)
  }
}

function allocationFor(total, capacities) {
  const allocations = capacities.map(() => 0)
  let remaining = total
  while (remaining > 0) {
    let progressed = false
    for (let i = 0; i < capacities.length && remaining > 0; i++) {
      if (allocations[i] < capacities[i]) {
        allocations[i] += 1
        remaining -= 1
        progressed = true
      }
    }
    if (!progressed) break
  }
  return allocations
}

function sanitizeStartBody(body) {
  const input = body || {}
  return {
    host: String(input.host || '').trim().slice(0, 253),
    port: Number(input.port),
    maxBots: Number(input.maxBots),
    joinDelayMs: Number(input.joinDelayMs),
    version: input.version ? String(input.version).trim().slice(0, 40) : '',
    defaultMode: String(input.defaultMode || 'wander'),
    followPlayer: String(input.followPlayer || '').trim().slice(0, 32),
    fullDiamondSpeedrun: parseBool(input.fullDiamondSpeedrun),
    authMode: ['none','login','register','login_or_register'].includes(input.authMode) ? input.authMode : 'none',
    authPassword: String(input.authPassword || '').slice(0, 128),
    loginCommand: String(input.loginCommand || '/login {password}').slice(0, 240),
    registerCommand: String(input.registerCommand || '/register {password} {password}').slice(0, 240),
    worldEntryEnabled: parseBool(input.worldEntryEnabled),
    worldCommand: String(input.worldCommand || '/rtp').slice(0, 240),
    worldWaitMs: Number(input.worldWaitMs),
    authWaitMs: Number(input.authWaitMs),
    startupTimeoutMs: Number(input.startupTimeoutMs),
    authorizedTestArea: parseBool(input.authorizedTestArea),
    testAreaRadius: Number(input.testAreaRadius),
    miningEnabled: parseBool(input.miningEnabled),
    combatEnabled: parseBool(input.combatEnabled),
    miningBlocks: Array.isArray(input.miningBlocks) ? input.miningBlocks.slice(0, 20).map(String) : [],
    autoReconnect: parseBool(input.autoReconnect),
    reconnectDelayMs: Number(input.reconnectDelayMs),
    maxReconnects: Number(input.maxReconnects),
    aiChatEnabled: parseBool(input.aiChatEnabled),
    ambientChatEnabled: parseBool(input.ambientChatEnabled),
    ambientIntervalMs: Number(input.ambientIntervalMs),
    aiAmbientEnabled: parseBool(input.aiAmbientEnabled)
  }
}

function parseBool(value) {
  if (typeof value === 'boolean') return value
  if (typeof value === 'number') return value !== 0
  return ['1','true','yes','on'].includes(String(value ?? '').trim().toLowerCase())
}

function publicStartBody(body, runId, workerCount) {
  const { authPassword, ...safe } = body
  return { ...safe, runId, startedAt: Date.now(), maxBots: body.maxBots, joinDelayMs: body.joinDelayMs, workerCount }
}

function getWorkerByBotId(id) {
  const text = String(id || '')
  const sep = text.indexOf(':')
  if (sep < 1) return null
  return workers.find(worker => worker.id === text.slice(0, sep)) || null
}

async function requireAllWorkers() {
  const results = await Promise.all(workers.map(async worker => {
    try { return { worker, health: await workerFetch(worker, '/healthz') } }
    catch (error) { return { worker, error } }
  }))
  const bad = results.filter(x => x.error || !x.health?.ok)
  if (bad.length) throw new Error(`Workers unavailable: ${bad.map(x => `${x.worker.id} (${x.error?.message || 'offline'})`).join(', ')}`)
  return results
}

app.get('/api/state', (_req, res) => res.json(aggregateState()))
app.get('/healthz', (_req, res) => {
  const snapshot = aggregateState()
  res.json({ ok: true, role: 'master', workers: snapshot.cluster.workerCount, onlineWorkers: snapshot.cluster.onlineWorkers, bots: snapshot.cluster.observedBots })
})

app.post('/api/start', async (req, res) => {
  if (masterRun || startInProgress) return res.status(409).json({ error: 'A cluster run is already active or starting' })
  startInProgress = true
  const body = sanitizeStartBody(req.body)
  if (!body.host || /[\u0000-\u001f\u007f]/.test(body.host) || !Number.isInteger(body.port) || body.port < 1 || body.port > 65535 || !Number.isInteger(body.maxBots) || body.maxBots < 1 || body.maxBots > MAX_TOTAL_BOTS) { startInProgress = false; return res.status(400).json({ error: `Valid host, port 1-65535 and maxBots 1-${MAX_TOTAL_BOTS} are required` }) }
  if (!body.authorizedTestArea) { startInProgress = false; return res.status(400).json({ error: 'Authorised test confirmation is required' }) }
  if (['login','register','login_or_register'].includes(body.authMode) && !body.authPassword.trim()) { startInProgress = false; return res.status(400).json({ error: 'Authentication password is required when auth mode is enabled' }) }

  try {
    const available = await requireAllWorkers()
    const capacities = available.map(item => Math.max(0, Number(item.health.maxBots || 0)))
    const allocations = allocationFor(body.maxBots, capacities)
    if (allocations.reduce((a,b) => a+b, 0) !== body.maxBots) {
      startInProgress = false
      return res.status(409).json({ error: `Not enough worker capacity for ${body.maxBots} bots; available capacity is ${allocations.reduce((a,b) => a+b, 0)}` })
    }
    const activeWorkers = []
    const workerCount = workers.length
    const globalDelay = Math.max(1000, Math.min(300_000, Number(body.joinDelayMs) || 5000))
    const localDelay = Math.min(3_600_000, globalDelay * workerCount)

    for (let i = 0; i < workers.length; i++) {
      if (!allocations[i]) continue
      const worker = workers[i]
      const payload = { ...body, maxBots: allocations[i], joinDelayMs: localDelay, spawnInitialDelayMs: i * globalDelay }
      delete payload.authPassword // restored below only for worker call
      payload.authPassword = body.authPassword
      try {
        await workerFetch(worker, '/api/start', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(payload) })
        activeWorkers.push(worker)
      } catch (error) {
        for (const started of activeWorkers) {
          try { await workerFetch(started, '/api/stop', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' }) } catch {}
        }
        throw error
      }
    }

    const runId = crypto.randomBytes(8).toString('hex')
    masterRun = { id: runId, public: publicStartBody(body, runId, workerCount) }
    emitLog(`Cluster run ${runId} started: ${body.maxBots} bots across ${activeWorkers.length} workers. Global join delay ${globalDelay}ms.`)
    await pollAll()
    startInProgress = false
    return res.json({ ok: true, runId, allocations: workers.map((worker, i) => ({ workerId: worker.id, bots: allocations[i] })) })
  } catch (error) {
    startInProgress = false
    return res.status(502).json({ error: error?.message || String(error) })
  }
})

app.post('/api/mode', async (req, res) => {
  const worker = getWorkerByBotId(req.body?.id)
  if (!worker) return res.status(400).json({ error: 'Bot id does not identify a known worker' })
  try {
    const data = await workerFetch(worker, '/api/mode', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(req.body || {}) })
    res.json(data)
  } catch (error) {
    res.status(502).json({ error: error?.message || String(error) })
  }
})

app.post('/api/stop', async (_req, res) => {
  const results = await Promise.allSettled(workers.map(worker => workerFetch(worker, '/api/stop', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' })))
  masterRun = null
  for (const result of results) if (result.status === 'rejected') emitLog(result.reason?.message || 'worker stop failed', 'warn')
  emitLog('Emergency Stop requested for all workers.', 'warn')
  await pollAll()
  res.json({ ok: true })
})

app.post('/api/logs/clear', async (_req, res) => {
  logBuffer = []
  await Promise.allSettled(workers.map(worker => workerFetch(worker, '/api/logs/clear', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' })))
  io.emit('logs', [])
  res.json({ ok: true })
})

io.engine.use((req, res, next) => basicAuth(req, res, next))
io.on('connection', socket => {
  const state = aggregateState()
  socket.emit('state', { run: state.run, bots: state.bots, cluster: state.cluster })
  socket.emit('logs', state.logs)
})

async function startServer() {
  if (!Number.isInteger(WEB_PORT) || WEB_PORT < 1 || WEB_PORT > 65535) throw new Error('WEB_PORT must be between 1 and 65535')
  if (!MASTER_WORKER_KEY) throw new Error('WORKER_API_KEY must match the worker API key')
  httpServer.listen(WEB_PORT, '0.0.0.0', () => {
    console.log(`Mineflayer Cluster Master listening on 0.0.0.0:${WEB_PORT}`)
    console.log(`Workers: ${workers.map(x => `${x.id}=${x.url}`).join(', ')}`)
    console.log(`Web authentication: ${authEnabled() ? 'enabled' : 'DISABLED'}`)
  })
  await pollAll()
  pollTimer = setInterval(() => { void pollAll().catch(error => emitLog(`Worker poll failed: ${error.message}`, 'warn')) }, POLL_MS)
}

async function shutdown(signal) {
  emitLog(`Shutdown requested (${signal}). Stopping cluster...`, 'warn')
  if (pollTimer) clearInterval(pollTimer)
  pollTimer = null
  await Promise.allSettled(workers.map(worker => workerFetch(worker, '/api/stop', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' })))
  masterRun = null
  startInProgress = false
  await new Promise(resolve => httpServer.close(() => resolve()))
}

if (require.main === module) {
  startServer().catch(error => { console.error(error); process.exit(1) })
  process.once('SIGINT', () => void shutdown('SIGINT'))
  process.once('SIGTERM', () => void shutdown('SIGTERM'))
}

module.exports = { app, httpServer, startServer, shutdown }
