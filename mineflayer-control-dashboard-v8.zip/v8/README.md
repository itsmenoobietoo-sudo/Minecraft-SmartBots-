# Mineflayer Cluster Control Dashboard v8

Master/worker architecture for an authorised Minecraft test environment. The dashboard runs on one small master instance; Mineflayer bot processes are sharded across multiple 16 GB worker containers.

## Architecture

- **Master**: one Express + Socket.IO dashboard. It polls workers, aggregates state/logs, distributes new runs and routes per-bot mode changes.
- **Workers**: one Node.js Mineflayer process per container. Each worker has an independent bot ceiling and is supervised by PM2.
- **Global join delay**: the master assigns each worker a different initial offset and makes its local delay `global delay × worker count`. That preserves one connection-start slot at the global cadence instead of creating bursts when multiple workers start together.
- **Safety boundary**: mining/combat actions remain limited to the project’s authorised test-area controls; there is no coordinated player-targeting swarm logic.

## Recommended 180 GB layout

A practical starting layout is **10 × 16 GB workers = 160 GB**, leaving roughly 20 GB for the master, OS, caches and operational headroom. Set `MAX_BOTS=200` on each worker for a 2,000-bot cluster. A worker can be given a different ceiling later, but benchmark the real workload before increasing it.

## Requirements

- Node.js 22+
- npm
- PM2
- Network reachability from master → every worker
- One long random `WORKER_API_KEY` shared by the master and workers

## Master setup

```bash
cd /path/to/mineflayer-cluster
cp .env.master.example .env
nano .env
npm install
npm run check
npm test
npm install -g pm2
npm start
```

The `WORKER_URLS` value uses this format:

```text
http://WORKER_IP:3101|w01,http://WORKER_IP:3101|w02,...
```

Keep worker ports private. Prefer an internal container network or a firewall rule allowing the worker port only from the master.

## Worker setup

Copy the project to each 16 GB container. On worker 01:

```bash
cd /path/to/mineflayer-cluster
cp .env.worker.example .env
nano .env
npm install
npm run check
npm install -g pm2
npm run start:worker
```

Set a unique `WORKER_ID` (`w01`, `w02`, etc.), its local `WORKER_PORT` (normally 3101), the shared `WORKER_API_KEY`, and `MAX_BOTS=200`. Repeat for each container.

For persistent PM2 supervision:

```bash
pm2 start ecosystem.worker.config.cjs
pm2 save
```

## Dashboard

Open the master dashboard on its configured `WEB_PORT` (default 3000). The browser talks only to the master. The master talks to workers with the private API key.

## Stopping the cluster

Use the dashboard Emergency Stop button, or:

```bash
pm2 stop mineflayer-master
```

The master sends a stop request to every configured worker during a clean SIGINT/SIGTERM shutdown. Each worker quits its Mineflayer bots and clears its timers before the HTTP server closes.

## Important runtime note

The code has static syntax and dashboard smoke tests, but this package does not include a live Minecraft integration server. Authentication prompts, `/rtp` behaviour, Mineflayer pathfinding/crafting/furnace APIs, reconnects and large-fleet memory usage should be benchmarked on the actual authorised test server before running a large fleet.
