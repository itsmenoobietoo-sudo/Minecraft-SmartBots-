module.exports = {
  apps: [{
    name: 'mineflayer-worker',
    script: './worker.js',
    instances: 1,
    exec_mode: 'fork',
    autorestart: true,
    watch: false,
    max_restarts: 30,
    exp_backoff_restart_delay: 250,
    node_args: '--max-old-space-size=10240',
    max_memory_restart: '14G'
  }]
}
