module.exports = {
  apps: [{
    name: 'mineflayer-master',
    script: './master.js',
    instances: 1,
    exec_mode: 'fork',
    autorestart: true,
    watch: false,
    max_restarts: 20,
    exp_backoff_restart_delay: 250,
    node_args: '--max-old-space-size=2048',
    max_memory_restart: '3G'
  }]
}
