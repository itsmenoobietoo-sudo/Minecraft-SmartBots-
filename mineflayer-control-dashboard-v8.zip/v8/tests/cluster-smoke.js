'use strict'

const fs = require('node:fs')
const path = require('node:path')
const { spawnSync } = require('node:child_process')

const root = path.resolve(__dirname, '..')
for (const file of ['master.js', 'worker.js']) {
  const result = spawnSync(process.execPath, ['--check', path.join(root, file)], { encoding: 'utf8' })
  if (result.status !== 0) {
    process.stderr.write(result.stderr || `${file} syntax check failed\n`)
    process.exit(1)
  }
}
const html = fs.readFileSync(path.join(root, 'public', 'index.html'), 'utf8')
for (const required of ['/api/start', '/api/stop', '/api/mode', '/api/logs/clear', 'workerCount']) {
  if (!html.includes(required)) throw new Error(`Dashboard is missing ${required}`)
}
console.log('cluster smoke: syntax + dashboard checks passed')
