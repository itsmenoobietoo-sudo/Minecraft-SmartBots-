# v8 cluster audit

## New architecture fixes

1. Master/worker split keeps bot memory inside the 16 GB worker boundary rather than assuming the host’s 180 GB is one process heap.
2. Worker API authentication uses a shared `X-Worker-Key`; worker HTTP and Socket.IO surfaces are protected.
3. Master requires every configured worker to pass a health check before starting a new fleet, preventing accidental partial starts.
4. Capacity is read from each worker and the requested total is rejected when the cluster cannot hold it.
5. Allocation is balanced one bot at a time across worker capacity.
6. Global connection pacing is preserved with per-worker offsets and a multiplied local interval, avoiding startup bursts across shards.
7. A master-side start lock prevents two concurrent start requests from launching overlapping cluster runs.
8. Partial worker startup rolls back previously started workers if a later worker refuses the run.
9. Bot IDs are prefixed with worker ID so mode commands can be routed back to the correct worker.
10. Master state aggregation marks offline workers without inventing bot state.
11. Master merges worker logs while tagging their worker IDs.
12. Master and worker APIs have POST origin checks and simple per-IP rate limiting.
13. Dashboard pagination limits DOM work to 50 bot cards at a time.
14. Live cluster UI exposes worker count/online worker count.
15. Test-area anchors now belong to each bot after world entry rather than being anchored at the lobby spawn. This avoids one worker’s lobby position or one `/rtp` result becoming the global anchor.
16. Worker auto-eat dynamic import retries after a failed module load.
17. Reconnect closes the old Mineflayer client before replacement to reduce duplicate socket lifetimes.
18. Startup/world-entry/auth timers are tracked so stop/mode changes can cancel them.
19. Large-fleet state emission is throttled more aggressively.
20. Ambient scheduler scans linearly rather than repeatedly filtering and sorting the full fleet.

## Remaining runtime verification

The code still needs a real authorised Minecraft server test for the Mineflayer event/API surface, especially auth plugins, world-change detection, pathfinding, crafting, furnaces, death/respawn and memory/CPU behaviour at the chosen per-worker bot count.
